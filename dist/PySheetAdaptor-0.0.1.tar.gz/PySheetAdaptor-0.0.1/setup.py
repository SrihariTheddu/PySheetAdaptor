from setuptools import setup

setup(
    name="PySheetAdaptor",
    version="0.0.1",
    description="PySheetAdaptor package is an interface to work with spreadsheets and python modules",
    long_description = """
    The main advantages of using this package is
    1. Configured with python Pandas module
    2. Every change is tracked and logged into a log file
    3. can backup data if the required state of lg file exists
    4. Can download the modified data as csv, html files.
    """,
    url = "",
    author = "Theddu Srihari",
    author_email = "sriharitheddu02@gmail.com",
    packages = [
                r"PySheetAdaptor\src",
                r"PySheetAdaptor\src\client",
                r"PySheetAdaptor\src\Manager",
                r"PySheetAdaptor\src\ResourceManager",
                r"PySheetAdaptor\src\webapp",
                r"PySheetAdaptor\src\tests",
                ],
    install_requires= ["oauth2client", "gspread", "pandas", "numpy", "django", "sqlalchemy"]
)


